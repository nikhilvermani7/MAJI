import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
// import {Routes,RouterModule} from '@angular/router'
import { CommonService } from './common.service';
import {FormsModule} from '@angular/forms'
import {HttpModule} from "@angular/http"
// const routes:Routes=[
//   {path:'app',component:AppComponent},
//   {path:'login',component:LoginComponent},
//   {path:'register',component:RegisterComponent}
// ]
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,HttpModule,FormsModule
  ],
  providers: [CommonService],
  bootstrap: [AppComponent]
})
export class AppModule { }
